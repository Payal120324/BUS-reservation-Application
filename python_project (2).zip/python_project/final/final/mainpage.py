#mainpage
from tkinter import *
from tkinter import ttk
import tkinter.messagebox
from PIL import Image,ImageTk
import mysql.connector
import tkinter as tk
import winsound
import emoji


root=Tk()
width1= root.winfo_screenwidth()               
height1= root.winfo_screenheight()
root.geometry("%dx%d" % (width1, height1))

def delete_pages():
    for frame in frame2.winfo_children():
        frame.destroy()

def homepage():
    delete_pages()
    
    def search_trip():
        query = search_entry.get()
    frame2.config(bg="#DCFFB7");

    search_label = Label(frame2, text="Search Your Trip here:", bg='#a9e8c0', font=('Arial',16))
    search_label.pack(side=TOP, pady=10)

    search_frame = Frame(frame2)  
    search_frame.pack(side=TOP, pady=10)

    search_entry = Entry(search_frame, width=150)
    search_entry.pack(side=LEFT, padx=10)

    search_button = Button(search_frame, text="Search", command=search_trip)
    search_button.pack(side=LEFT, padx=10)

    offers_label = Label(frame2, text="Offers:", bg='#a9e8c0',font=('Arial', 16))
    offers_label.pack(side=TOP, pady=25)

    offers_text = Text(frame2, height=10, width=150)
    offers_text.pack(side=TOP, padx=10, pady=10)

    
    offers_text.insert(END, "1. 20% off on all bookings\n", ('offer',))
    offers_text.insert(END, "2. Free meal on selected routes\n", ('offer',))
    offers_text.insert(END, "3. Flat ₹500 discount on weekend trips\n", ('offer',))

    offers_text.tag_configure('offer', font=('Arial', 15), spacing1=10, spacing2=5, spacing3=10)

    def remove_message():
        thanks_label.pack_forget()

    def submit_review():
        review = review_text.get("1.0", END)
        rating = rating_scale.get()
        print("Submitted Review:", review)
        print("Rating:", rating)

        global thanks_label
        thanks_label = Label(frame2, text="Thanks for rating!", bg='#6AFB92', font=('Arial', 20))
        thanks_label.pack(side=TOP, pady=10)

        def remove_message():
            thanks_label.pack_forget()

        frame2.after(2000, remove_message) 

    reviews_label = Label(frame2, text="Customer Review:", bg='#a9e8c0', font=('Arial', 14))
    reviews_label.pack(side=TOP, pady=10)

    review_text = Text(frame2, height=5, width=110, font=('Arial', 16))
    review_text.pack(side=TOP, padx=10, pady=5)

    rating_label = Label(frame2, text="Rate This Trip:", bg='#a9e8c0', font=('Arial', 16))
    rating_label.pack(side=TOP, pady=5)

    rating_scale = Scale(frame2, from_=1, to=5, orient=HORIZONTAL, length=200)
    rating_scale.pack(side=TOP, pady=5)

    submit_button = Button(frame2, text="Submit Review", command=submit_review)
    submit_button.pack(side=TOP, pady=10)

def aboutpage():
    delete_pages()
    import bookentire
def bookingpage():
    delete_pages()
    import reservation 

    

def cancelpage():
    delete_pages()
    import bhakticancellation
def feedpage():
    delete_pages()
    def submit_feedback():
        play_sound()
        display_feedback()

    def play_sound():
        winsound.PlaySound("button_click.wav", winsound.SND_FILENAME)

    def display_feedback():
        feedback_text = [
        feedback1.get("1.0", "end-1c"),
        feedback2.get("1.0", "end-1c"),
        feedback3.get("1.0", "end-1c"),
        feedback4.get("1.0", "end-1c")
    ]
        satisfaction_scale = overall_satisfaction.get()
        stars = "⭐" * int(satisfaction_scale)
        feedback_msg = f"Feedback Summary:\n\n" \
                   f"1. Did the app perform well without any glitches or crashes? {feedback_text[0]}\n\n" \
                   f"2. Additional features you would like to see added: {feedback_text[1]}\n\n" \
                   f"3. Share about your experience with the app: {feedback_text[2]}\n\n" \
                   f"4. Did the app have all the features you expected? {feedback_text[3]}"
        feedback_msg += f"\n\nSatisfaction Scale: {stars}"
        messagebox.showinfo("Feedback Summary", feedback_msg)

    root = tk.Tk()
    root.geometry("500x500")
    root.title("FEEDBACK PAGE")
    root.config(bg="#4ef5b2")
    

# Background Image
##    bg_image = tk.PhotoImage(file=r"C:\\Users\\gargi\\OneDrive\\Desktop\\final\\payal.jpg")  # Change the path accordingly
##    background_label = tk.Label(root, image=bg_image)
##    background_label.place(x=0, y=0, relwidth=1, relheight=1)

# Labels and Entries for username and email
    tk.Label(root, text="Username:", bg="yellow", fg="black").grid(row=0, column=0, padx=10, pady=5)
    e1 = tk.Entry(root, bg="white", fg="black")
    e1.grid(row=0, column=1, padx=10, pady=5)

    tk.Label(root, text="E-mail id:", bg="yellow", fg="black").grid(row=1, column=0, padx=10, pady=5)
    e2 = tk.Entry(root, bg="white", fg="black")
    e2.grid(row=1, column=1, padx=10, pady=5)

# Feedback Questions with Text widgets
    tk.Label(root, text="Did the app perform well without any glitches or crashes?", bg="yellow", fg="black").grid(row=2, column=0, padx=10, pady=5)
    feedback1 = tk.Text(root, height=3, width=40, bg="white", fg="black")
    feedback1.grid(row=2, column=1, padx=10, pady=5)

    tk.Label(root, text="Additional features you would like to see added:", bg="yellow", fg="black").grid(row=3, column=0, padx=10, pady=5)
    feedback2 = tk.Text(root, height=3, width=40, bg="white", fg="black")
    feedback2.grid(row=3, column=1, padx=10, pady=5)

    tk.Label(root, text="Share about your experience with the app:", bg="yellow", fg="black").grid(row=4, column=0, padx=10, pady=5)
    feedback3 = tk.Text(root, height=3, width=40, bg="white", fg="black")
    feedback3.grid(row=4, column=1, padx=10, pady=5)

    tk.Label(root, text="Did the app have all the features you expected?", bg="yellow", fg="black").grid(row=5, column=0, padx=10, pady=5)
    feedback4 = tk.Text(root, height=3, width=40, bg="white", fg="black")
    feedback4.grid(row=5, column=1, padx=10, pady=5)

# Scale for overall satisfaction
    tk.Label(root, text="Overall Satisfaction:", bg="yellow", fg="black").grid(row=6, column=0, padx=10, pady=5)
    overall_satisfaction = tk.Scale(root, from_=1, to=5, orient=tk.HORIZONTAL)
    overall_satisfaction.grid(row=6, column=1, padx=10, pady=5)

# Submit Button
    submit_button = tk.Button(root, text="Submit", bg="green", fg="white", command=submit_feedback)
    submit_button.grid(row=7, columnspan=2, padx=10, pady=10)


frame3=Frame(root)
frame1=Frame(root)
frame2=Frame(root)
frame3.config(width=width1,height=50,bg='#83ebd3')
frame2.config(width=1000, height=height1,bg='white')
frame1.config(width=1,height=height1,bg='#a9e8c0')

homepage()
step1=Button(frame1,text="Best Bus Booking App",font=('bold',12),height=2,width=20,bg='#45b592',fg='#ffffff', bd=0,activebackground='#347061',activeforeground='white')
step1.place(x=20,y=250)

step1_indicate=Label(frame1,text='',bg='#83ebd3')
step1_indicate.place(x=5,y=250,width=5,height=40)

step2=Button(frame1,text="Best Offers!!",height=2,width=20,font=('Bold',12),bg='#45b592',fg='#ffffff',bd=0,activebackground='#347061',activeforeground='white')
step2.place(x=20,y=350)
step2_indicate=Label(frame1,text='',bg='#83ebd3')
step2_indicate.place(x=5,y=350,width=5,height=40)

step3=Button(frame1,text="Book Your Tickets Now!",height=2,width=20,font=('Bold',12),command=  lambda: indicate(step3_indicate),bg='#45b592',fg='#ffffff',bd=0,activebackground='#347061',activeforeground='white')
step3.place(x=20,y=450)
step3_indicate=Label(frame1,text='',bg='#83ebd3')
step3_indicate.place(x=5,y=450,width=5,height=40)

label2=Label(frame2,text="this is window two")
label2.pack(pady=50,padx=20)

label_logo=Label(frame1,text="Logo",bg="#24664b",height=10,width=16)
label_logo.place(x=50,y=40)

label_logo2=Label(frame3,text="Logo2",bg="#24664b",height=4,width=7)
label_logo2.place(x=120,y=3)


but3=Button(frame3,text="feedback",bg='#83ebd3',font=('Arial',15),bd=0,command=feedpage)
but3.pack(side=RIGHT,padx=40)

but4=Button(frame3,text="Charter",bg='#83ebd3',font=('Arial',15),bd=0,command=aboutpage)
but4.pack(side=RIGHT,padx=40)




but7=Button(frame3,text="cancellation",bg='#83ebd3',font=('Arial',15),bd=0,command=cancelpage)
but7.pack(side=RIGHT,padx=40)
but6=Button(frame3,text="ticket booking",bg='#83ebd3',font=('Arial',15),bd=0,command=bookingpage)
but6.pack(side=RIGHT,padx=40)

but5=Button(frame3,text="home",bg='#83ebd3',font=('Arial',15),bd=0,command=homepage)
but5.pack(side=RIGHT,padx=40)



frame3.pack(fill=BOTH,expand=True,side=TOP)
frame3.pack_propagate(0)



frame1.pack(fill=BOTH,expand=True,side=LEFT)

frame1.pack_propagate(0)

frame2.pack(fill=BOTH,expand=True,side=LEFT)
frame2.pack_propagate(0)

